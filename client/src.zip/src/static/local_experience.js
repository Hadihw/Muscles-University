const localExperience = [
    {
        company_logo: "/src/static/images/companies/google.png",
        company: "Google Inc.",
        position: "Software Engineer",
        startDate: "May 2022",
        endDate: "Present",
        country: "United States",
        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.",
    },
    {
        company_logo: "/src/static/images/companies/microsoft.png",
        company: "Microsoft Inc.",
        position: "Software Engineer Intern",
        startDate: "December 2021",
        endDate: "April 2022",
        country: "United States",
        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.",
    },
    {
        company_logo: "/src/static/images/companies/meta.png",
        company: "Meta Inc.",
        position: "QA Engineer Intern",
        startDate: "January 2021",
        endDate: "May 2021",
        country: "United States",
        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.",
    },
]

export default localExperience;