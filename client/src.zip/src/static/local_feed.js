const firstFeed = [
    {
        name: "Khalid Sadat",
        occupation: "Software Engineer",
        date: "3d",
        post: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.",
        likes: "120",
        comments: "30",
    },
    {
        name: "Team SOEN 390",
        occupation: "Project Team",
        date: "3w",
        post: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.",
        likes: "10k",
        comments: "2.5k",
    },
    {
        name: "Best Team",
        occupation: "Documentation",
        date: "3 months",
        post: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.",
        likes: "120k",
        comments: "305k",
    }
]

export default firstFeed;