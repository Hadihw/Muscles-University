const localEducation = [
    {
        school_logo: "/src/static/images/education/concordia.png",
        school_name: "Concordia University",
        degree: "Bachelor of Engineering - BE, Software Engineering",
        startDate: "Jan 2021",
        endDate: "Present",
        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit.",
    },
    {
        school_logo: "/src/static/images/education/vanier.png",
        school_name: "Vanier College",
        degree: "DEC Computer Science Technology",
        startDate: "January 2017",
        endDate: "May 2020",
        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque.",
    },
]

export default localEducation;