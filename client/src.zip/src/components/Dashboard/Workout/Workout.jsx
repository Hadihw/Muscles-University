import React from 'react';

import {
	FaRunning,

} from 'react-icons/fa';
import Camera from "../../Camera/Camera";

const Workout = () => {
	const brandColors = {
		medium: '#9F8157',
		dark: '#745228',
		light: '#FBEDC7',
	};

	const Card = ({ title, icon: Icon, children }) => (
		<div className="flex flex-col bg-white rounded-lg shadow-lg p-6">
			<div className="flex items-center mb-4">
				<Icon size={28} style={{ color: brandColors.dark }} />
				<h3 className="text-xl font-semibold ml-3">{title}</h3>
			</div>
			{children}
		</div>
	);

	return (
		<>
			<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

				{/* Workout Progress */}
				<Card title="Workout Progress" icon={FaRunning}>
					<div className="flex items-center justify-between">
						<p className="text-sm font-medium">Cardio</p>
						<div className="w-16 h-2 bg-gray-200 rounded-full">
							<div
								className="h-full bg-green-500 rounded-full"
								style={{ width: '60%' }}
							/>
						</div>
					</div>
					<div className="flex items-center justify-between mt-4">
						<p className="text-sm font-medium">Strength</p>
						<div className="w-16 h-2 bg-gray-200 rounded-full">
							<div
								className="h-full bg-blue-500 rounded-full"
								style={{ width: '80%' }}
							/>
						</div>
					</div>
					<div className="flex items-center justify-between mt-4">
						<p className="text-sm font-medium">Flexibility</p>
						<div className="w-16 h-2 bg-gray-200 rounded-full">
							<div
								className="h-full bg-yellow-500 rounded-full"
								style={{ width: '50%' }}
							/>
						</div>
					</div>
				</Card>

				<Card title="Form Correction" icon={FaRunning}>
					<Camera />
				</Card>
			</div>

		</>
	);
};

export default Workout;