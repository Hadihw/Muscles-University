import React, { useState } from 'react';

const ProfileInput = ({ label, value, onChange }) => {
	const [isEditing, setIsEditing] = useState(false);

	return (
		<div className="mb-4">
			<label className="block text-gray-700 text-sm font-semibold mb-2">
				{label}
			</label>
			{isEditing ? (
				<div className="flex items-center">
					<input
						value={value}
						onChange={onChange}
						className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
					/>
					<button
						onClick={() => setIsEditing(false)}
						className="ml-2 bg-red-500 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
					>
						Save
					</button>
				</div>
			) : (
				<div className="flex items-center">
					<span className="text-gray-700">{value}</span>
					<button
						onClick={() => setIsEditing(true)}
						className="ml-2 text-sm text-blue-500"
					>
						Edit
					</button>
				</div>
			)}
		</div>
	);
};

const Profile = () => {
	const [name, setName] = useState('John Doe');
	const [email, setEmail] = useState('johndoe@example.com');
	const [calories, setCalories] = useState('2000');
	const [fat, setFat] = useState('70g');
	const [protein, setProtein] = useState('150g');
	const [carbs, setCarbs] = useState('250g');
	const [allergies, setAllergies] = useState('Peanuts');
	const [dietaryRequirements, setDietaryRequirements] = useState('Vegetarian');
	const [foodPreference, setFoodPreference] = useState('Indian');
	const [workoutLocation, setWorkoutLocation] = useState('Gym');
	const [gender, setGender] = useState('Male');
	const [currentWeight, setCurrentWeight] = useState('180 lbs');
	const [goalWeight, setGoalWeight] = useState('160 lbs');
	const [age, setAge] = useState('30');
	const [height, setHeight] = useState("5'10\"");
	const [fitnessGoal, setFitnessGoal] = useState('Lose weight');
	const [dailyActivities, setDailyActivities] = useState('Sedentary');

	return (
		<div className="h-full w-full p-8">
			<div className="bg-white rounded-lg shadow-lg h-full p-8 flex flex-col space-y-6">
				<div className="grid grid-cols-2 gap-8">
					{/* Left Column */}
					<div className="space-y-6">
						{/* Personal Info */}
						<div className="space-y-4">
							<div className="flex items-center mb-6">
								<img
									src="https://via.placeholder.com/100"
									alt="Profile"
									className="rounded-full w-24 h-24 mr-6"
								/>
								<div className="flex flex-col space-y-2">
									<h3 className="text-xl font-semibold">{name}</h3>
									<p className="text-sm text-gray-500">{email}</p>
								</div>
							</div>
							<ProfileInput
								label="Gender"
								value={gender}
								onChange={(e) => setGender(e.target.value)}
							/>
							<ProfileInput
								label="Age"
								value={age}
								onChange={(e) => setAge(e.target.value)}
							/>
							<ProfileInput
								label="Height"
								value={height}
								onChange={(e) => setHeight(e.target.value)}
							/>
						</div>

						{/* Nutrition */}
						<div className="space-y-4">
							<h2 className="text-2xl font-semibold mb-4">Nutrition</h2>
							<div className="grid grid-cols-2 gap-4">
								<ProfileInput
									label="Calories"
									value={calories}
									onChange={(e) => setCalories(e.target.value)}
								/>
								<ProfileInput
									label="Fat"
									value={fat}
									onChange={(e) => setFat(e.target.value)}
								/>
								<ProfileInput
									label="Protein"
									value={protein}
									onChange={(e) => setProtein(e.target.value)}
								/>
								<ProfileInput
									label="Carbs"
									value={carbs}
									onChange={(e) => setCarbs(e.target.value)}
								/>
							</div>
							<div className="grid grid-cols-3 gap-4 mt-4">
								<ProfileInput
									label="Allergies"
									value={allergies}
									onChange={(e) => setAllergies(e.target.value)}
								/>
								<ProfileInput
									label="Dietary Requirements"
									value={dietaryRequirements}
									onChange={(e) => setDietaryRequirements(e.target.value)}
								/>
								<ProfileInput
									label="Food Preference"
									value={foodPreference}
									onChange={(e) => setFoodPreference(e.target.value)}
								/>
							</div>
						</div>
					</div> {/* Right Column */}
					<div className="space-y-6">
						{/* Workout and Fitness */}
						<div className="space-y-4">
							<h2 className="text-2xl font-semibold mb-4">Workout and Fitness</h2>
							<div className="grid grid-cols-2 gap-4">
								<ProfileInput
									label="Workout Location"
									value={workoutLocation}
									onChange={(e) => setWorkoutLocation(e.target.value)}
								/>
								<ProfileInput
									label="Current Weight"
									value={currentWeight}
									onChange={(e) => setCurrentWeight(e.target.value)}
								/>
								<ProfileInput
									label="Goal Weight"
									value={goalWeight}
									onChange={(e) => setGoalWeight(e.target.value)}
								/>
								<ProfileInput
									label="Fitness Goal"
									value={fitnessGoal}
									onChange={(e) => setFitnessGoal(e.target.value)}
								/>
								<ProfileInput
									label="Daily Activities"
									value={dailyActivities}
									onChange={(e) => setDailyActivities(e.target.value)}
								/>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Profile;