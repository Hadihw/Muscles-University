import React, {useState} from 'react';
import {NavLink,useNavigate} from 'react-router-dom';
import {
	FaHome,
	FaHeartbeat,
	FaRunning,
	FaUserCircle,
	FaCommentAlt,
	FaChartLine,
	FaCalendarAlt,
	FaSignOutAlt, FaBars
} from 'react-icons/fa';

const DashboardNavbar = ({ onTabChange }) => {
	const [menuOpen, setMenuOpen] = useState(false);
	const handleTabClick = (tabName) => {
		onTabChange(tabName);
	};

	const navigate = useNavigate();

	const logout = () => {
		localStorage.removeItem("uid");
		localStorage.removeItem("loggedIn");
		navigate("/login");
	};

	return (
		<nav className="bg-light shadow-lg h-full flex flex-col items-center py-6 space-y-4">
			<div className="flex flex-col h-full w-full">
				<div className="w-52 mb-10">
					<img src="../../../assets/images/logo(500x500).png" alt="Logo" className="w-full h-auto mb-10" />
				</div>
				<button
					onClick={() => setMenuOpen(!menuOpen)}
					className="lg:hidden text-dark text-xl mb-6"
				>
					<FaBars />
				</button>
				<div
					className={`${
						menuOpen ? 'block' : 'hidden'
					} lg:block w-full flex flex-col items-center space-y-4`}
				>
					{/* Home */}
					<NavLink
						to="/Home"
						onClick={() => handleTabClick('home')}
						activeClassName="bg-dark text-white px-4 py-2 rounded-md"
						className="w-full px-4 py-2 rounded-md flex items-center justify-start space-x-2 border-transparent"
					>
						<FaHome className="w-8 h-8" />
						<span>Home</span>
					</NavLink>

					{/* Profile */}
					<NavLink
						to="/Profile"
						onClick={() => handleTabClick('profile')}
						activeClassName="bg-dark text-white px-4 py-2 rounded-md"
						className="w-full mb-6 px-4 py-2 rounded-md flex items-center justify-start space-x-2 border-transparent"
					>
						<FaUserCircle className="w-8 h-8" />
						<span>Profile</span>
					</NavLink>

					{/* Messages */}
					<NavLink
						to="/Messages"
						onClick={() => handleTabClick('messages')}
						activeClassName="bg-dark text-white px-4 py-2 rounded-md"
						className="w-full mb-6 px-4 py-2 rounded-md flex items-center justify-start space-x-2 border-transparent"
					>
						<FaCommentAlt className="w-8 h-8" />
						<span>Messages</span>
					</NavLink>

					{/* Statistics */}
					<NavLink
						to="/Statistics"
						onClick={() => handleTabClick('statistics')}
						activeClassName="bg-dark text-white px-4 py-2 rounded-md"
						className="w-full mb-6 px-4 py-2 rounded-md flex items-center justify-start space-x-2 border-transparent"
					>
						<FaChartLine className="w-8 h-8" />
						<span>Statistics</span>
					</NavLink>

					{/* Workout */}
					<NavLink
						to="/Workout"
						onClick={() => handleTabClick('workout')}
						activeClassName="bg-dark text-white px-4 py-2 rounded-md"
						className="w-full mb-6 px-4 py-2 rounded-md flex items-center justify-start space-x-2 border-transparent"
					>
						<FaRunning className="w-8 h-8" />
						<span>Workout</span>
					</NavLink>

					{/* Activities */}
					<NavLink
						to="/Activities"
						onClick={() => handleTabClick   ('activities')}
						activeClassName="bg-dark text-white px-4 py-2 rounded-md"
						className="w-full mb-6 px-4 py-2 rounded-md flex items-center justify-start space-x-2 border-transparent"
					>
						<FaCalendarAlt className="w-8 h-8" />
						<span>Activities</span>
					</NavLink>

					{/* Other elements... */}
				</div>

				{/* Logout */}
				<button
					onClick={logout}
					className="w-full mb-6 px-4 py-2 rounded-md flex items-center justify-start space-x-2 border-transparent"
				>
					<FaSignOutAlt className="w-8 h-8" />
					<span>Logout</span>
				</button>
			</div>
		</nav>
	);
};

export default DashboardNavbar;