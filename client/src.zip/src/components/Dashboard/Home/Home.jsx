import React from 'react';
import {
	FaHeartbeat,
	FaRunning,
	FaUserCircle,
	FaCommentAlt,
	FaChartLine,
	FaCalendarAlt,
} from 'react-icons/fa';

const Home = () => {
	const brandColors = {
		medium: '#9F8157',
		dark: '#745228',
		light: '#FBEDC7',
	};

	const Card = ({ title, icon: Icon, children }) => (
		<div className="flex flex-col bg-white rounded-lg shadow-lg p-6">
			<div className="flex items-center mb-4">
				<Icon size={28} style={{ color: brandColors.dark }} />
				<h3 className="text-xl font-semibold ml-3">{title}</h3>
			</div>
			{children}
		</div>
	);

	return (
		<div className="flex-1 p-8 bg-gray-100">
			{/* Header */}
			<div className="mb-8">
				<h1 className="text-3xl font-semibold mb-4">Welcome, John Doe</h1>
				<div className="bg-white p-4 rounded-lg shadow-md">
					<p>Your last login was on <strong>15th August, 2023</strong> at <strong>14:32 PM</strong></p>
				</div>
			</div>

			{/* Main Content */}
			<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
				{/* Profile Card */}
				<Card title="Profile" icon={FaUserCircle}>
					<div className="flex items-center">
						<div className="w-16 h-16 bg-gray-300 rounded-full mr-4" />
						<div>
							<p className="text-lg font-medium">John Doe</p>
							<p className="text-sm text-gray-500">Member since Jan 2021</p>
						</div>
					</div>
					<div className="mt-6">
						<p className="text-sm font-medium">Personal Information:</p>
						<ul className="list-disc list-inside text-xs pl-4 mt-2">
							<li>Age: 30</li>
							<li>Weight: 165 lbs</li>
							<li>Height: 5'10"</li>
						</ul>
					</div>
				</Card>

				{/* Messages Card */}
				<Card title="Messages" icon={FaCommentAlt}>
					<div className="divide-y divide-gray-200">
						{Array.from({ length: 3 }).map((_, i) => (
							<div key={i} className="py-2">
								<p className="text-sm font-medium">Sender {i + 1}</p>
								<p className="text-xs text-gray-500">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit.
								</p>
							</div>
						))}
					</div>
					<button
						type="button"
						className="mt-6 w-full text-sm font-medium text-white py-2 rounded-md"
						style={{ backgroundColor: brandColors.medium }}
					>
						View All Messages
					</button>
				</Card>

				{/* Statistics Card */}
				<Card title="Statistics" icon={FaChartLine}>
					<ul className="space-y-4">
						{[
							{ label: 'Active Days', value: '12', icon: FaCalendarAlt },
							{ label: 'Miles Run', value: '40', icon: FaRunning },
							{ label: 'Avg. Heart Rate', value: '120 BPM', icon: FaHeartbeat },
						].map((stat) => (
							<li key={stat.label} className="flex items-center">
								<stat.icon size={20} className="text-gray-500" />
								<p className="text-sm ml-3">
									{stat.label}: <span className="font-semibold">{stat.value}</span>
								</p>
							</li>
						))}
					</ul>
				</Card>

				{/* Workout Progress Card */}
				<Card title="Workout Progress" icon={FaRunning}>
					<div className="flex items-center justify-between">
						<p className="text-sm font-medium">Cardio</p>
						<div className="w-16 h-2 bg-gray-200 rounded-full">
							<div
								className="h-full bg-green-500 rounded-full"
								style={{ width: '60%' }}
							/>
						</div>
					</div>
					<div className="flex items-center justify-between mt-4">
						<p className="text-sm font-medium">Strength</p>
						<div className="w-16 h-2 bg-gray-200 rounded-full">
							<div
								className="h-full bg-blue-500 rounded-full"
								style={{ width: '80%' }}
							/>
						</div>
					</div>
					<div className="flex items-center justify-between mt-4">
						<p className="text-sm font-medium">Flexibility</p>
						<div className="w-16 h-2 bg-gray-200 rounded-full">
							<div
								className="h-full bg-yellow-500 rounded-full"
								style={{ width: '50%' }}
							/>
						</div>
					</div>
				</Card>

				{/* Upcoming Activities Card */}
				<Card title="Upcoming Activities" icon={FaCalendarAlt}>
					<ul className="divide-y divide-gray-200">
						{Array.from({ length: 3 }).map((_, i) => (
							<li key={i} className="py-2">
								<p className="text-sm font-medium">Activity {i + 1}</p>
								<p className="text-xs text-gray-500">March 30, 2023</p>
							</li>
						))}
					</ul>
					<button
						type="button"
						className="mt-6 w-full text-sm font-medium text-white py-2 rounded-md"
						style={{ backgroundColor: brandColors.medium }}
					>
						View All Activities
					</button>
				</Card>
			</div>
		</div>
	);
};

export default Home;